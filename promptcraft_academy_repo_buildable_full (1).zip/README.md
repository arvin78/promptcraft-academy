# PromptCraft Academy (Flutter, Android)

این ریپو به‌صورت «ZIP → GitHub Actions → APK» طراحی شده تا حتی اگر برنامه‌نویسی بلد نیستی بتوانی خروجی APK بگیری.

## خروجی گرفتن APK در GitHub
1. فایل ZIP را داخل Repo آپلود کن.
2. فایل workflow را یک‌بار بساز/بگذار.
3. از تب Actions اجرا کن و APK را از Artifacts دانلود کن.

## توسعه محتوا (بدون کدنویسی)
- فایل مسیر آموزشی: `assets/data/curriculum_fa.json`
- فایل کوییزها: `assets/data/quizzes_fa.json`
- فایل فلش‌کارت‌ها: `assets/data/flashcards_fa.json`
- متن هر درس: `assets/lessons/<lessonId>.md`

## نکته
این پروژه آفلاین کار می‌کند و پیشرفت شما را با `SharedPreferences` ذخیره می‌کند.

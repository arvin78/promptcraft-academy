import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'features/dashboard/dashboard_page.dart';
import 'features/curriculum/curriculum_page.dart';
import 'features/library/library_page.dart';
import 'features/review/review_page.dart';
import 'features/tools/tools_page.dart';
import 'features/settings/settings_page.dart';

class PromptCraftApp extends StatelessWidget {
  const PromptCraftApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PromptCraft Academy',
      debugShowCheckedModeBanner: false,
      locale: const Locale('fa'),
      supportedLocales: const [Locale('fa'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      builder: (context, child) {
        return Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox());
      },
      home: const _Shell(),
    );
  }
}

class _Shell extends StatefulWidget {
  const _Shell();

  @override
  State<_Shell> createState() => _ShellState();
}

class _ShellState extends State<_Shell> {
  int index = 0;

  final pages = const [
    DashboardPage(),
    CurriculumPage(),
    ReviewPage(),
    ToolsPage(),
    LibraryPage(),
    SettingsPage(),
  ];

  final labels = const ['داشبورد', 'مسیر', 'مرور', 'ابزارها', 'کتابخانه', 'تنظیمات'];

  final icons = const [
    Icons.dashboard_outlined,
    Icons.account_tree_outlined,
    Icons.style_outlined,
    Icons.build_outlined,
    Icons.local_library_outlined,
    Icons.settings_outlined,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: [
          for (int i = 0; i < pages.length; i++)
            NavigationDestination(
              icon: Icon(icons[i]),
              label: labels[i],
            )
        ],
      ),
    );
  }
}

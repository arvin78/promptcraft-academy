import 'package:flutter/material.dart';
import '../../models/course.dart';
import '../../services/content_repository.dart';
import '../../services/progress_store.dart';
import '../../widgets/module_tree.dart';
import '../lesson/lesson_page.dart';

class CurriculumPage extends StatefulWidget {
  const CurriculumPage({super.key});

  @override
  State<CurriculumPage> createState() => _CurriculumPageState();
}

class _CurriculumPageState extends State<CurriculumPage> {
  final repo = ContentRepository();
  final store = ProgressStore();

  List<Module> modules = const [];
  Set<String> completed = const {};
  bool loading = true;
  String? error;
  String query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final m = await repo.loadModulesFa();
      final c = await store.getCompleted();
      setState(() {
        modules = m;
        completed = c;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  List<Module> _filtered() {
    if (query.trim().isEmpty) return modules;
    final q = query.trim().toLowerCase();
    final filtered = <Module>[];
    for (final m in modules) {
      final lessons = m.lessons.where((l) {
        return l.title.toLowerCase().contains(q) ||
            l.tags.any((t) => t.toLowerCase().contains(q)) ||
            l.level.toLowerCase().contains(q);
      }).toList();
      if (m.title.toLowerCase().contains(q) || lessons.isNotEmpty) {
        filtered.add(Module(id: m.id, title: m.title, summary: m.summary, lessons: lessons.isNotEmpty ? lessons : m.lessons));
      }
    }
    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مسیر آموزشی'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                      child: TextField(
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText: 'جستجو: عنوان درس، تگ‌ها، سطح...',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (v) => setState(() => query = v),
                      ),
                    ),
                    Expanded(
                      child: ModuleTree(
                        modules: _filtered(),
                        completed: completed,
                        onOpenLesson: (lesson) async {
                          await Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => LessonPage(lesson: lesson)),
                          );
                          await _load();
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}

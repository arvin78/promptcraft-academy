import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      // ignore
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = const [
      ('Prompt Engineering Survey (NLP)', 'https://arxiv.org/abs/2406.06608'),
      ('Automated Prompt Engineering Survey', 'https://arxiv.org/abs/2401.11698'),
      ('RAG Evaluation Survey', 'https://arxiv.org/abs/2401.05845'),
      ('LLM Agents for QA Survey', 'https://arxiv.org/abs/2501.04682'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('کتابخانه')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('این بخش چند منبع منتخب را لیست می‌کند. (برای مشاهده اینترنت لازم است)'),
          const SizedBox(height: 12),
          for (final it in items)
            Card(
              child: ListTile(
                title: Text(it.$1),
                subtitle: Text(it.$2),
                trailing: const Icon(Icons.open_in_new),
                onTap: () => _open(it.$2),
              ),
            ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../../models/course.dart';
import '../../services/content_repository.dart';
import '../../services/progress_store.dart';
import '../quiz/quiz_page.dart';

class LessonPage extends StatefulWidget {
  final LessonRef lesson;
  const LessonPage({super.key, required this.lesson});

  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  final repo = ContentRepository();
  final store = ProgressStore();

  bool loading = true;
  String? error;
  String md = '';
  bool completed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final c = await store.getCompleted();
      final text = await repo.loadLessonMarkdown(widget.lesson.id);
      setState(() {
        completed = c.contains(widget.lesson.id);
        md = text;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _toggleComplete() async {
    final set = await store.getCompleted();
    if (set.contains(widget.lesson.id)) {
      set.remove(widget.lesson.id);
    } else {
      set.add(widget.lesson.id);
    }
    await store.setCompleted(set);
    setState(() => completed = set.contains(widget.lesson.id));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.lesson.title),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
          IconButton(
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => QuizPage(lessonId: widget.lesson.id, lessonTitle: widget.lesson.title)),
              );
            },
            icon: const Icon(Icons.quiz_outlined),
            tooltip: 'کوییز',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _toggleComplete,
        icon: Icon(completed ? Icons.check_circle : Icons.check_circle_outline),
        label: Text(completed ? 'کامل شد' : 'علامت‌گذاری به‌عنوان انجام‌شده'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : Markdown(
                  data: md,
                  selectable: true,
                ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SuperPromptPage extends StatelessWidget {
  const SuperPromptPage({super.key});

  static const prompt = '''
نقش شما:
تو یک تیم کامل هستی: (1) معمار نرم‌افزار (2) مهندس ارشد اندروید/Flutter (3) طراح UI/UX حرفه‌ای (4) مهندس QA/تست (5) نویسنده مستندات فنی.

هدف:
تولید یک ریپوی GitHub کاملاً آماده که بدون سوال اضافه، خروجی APK اندروید بدهد و استانداردهای حرفه‌ای را رعایت کند.

قید مهم:
کاربر مبتدی مطلق است؛ خروجی باید قدم‌به‌قدم، بی‌ابهام، و قابل اجرا باشد. اگر چیزی مبهم بود، فرض معقول بساز و در جدول Assumptions بنویس.

تحویل‌ها:
- پروژه Flutter (Android-first) + ساختار تمیز
- README کامل + دستورالعمل GitHub
- GitHub Actions برای build apk/aab
- مدیریت خطا در سطح محصول + logging
- تست‌های پایه + چک‌لیست Release readiness

Quality Gate:
قبل از پایان، بخش Final verification بنویس که شامل:
- flutter analyze بدون error
- build apk موفق
- مسیر دانلود APK در GitHub
- ریسک‌ها و راه‌های کاهش ریسک
''';

  Future<void> _copy(BuildContext context) async {
    await Clipboard.setData(const ClipboardData(text: prompt));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کپی شد')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Super Prompt'),
        actions: [
          IconButton(onPressed: () => _copy(context), icon: const Icon(Icons.copy)),
        ],
      ),
      body: const Padding(
        padding: EdgeInsets.all(16),
        child: SelectableText(prompt),
      ),
    );
  }
}

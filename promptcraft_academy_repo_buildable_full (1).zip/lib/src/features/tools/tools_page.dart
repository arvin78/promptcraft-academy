import 'package:flutter/material.dart';
import 'prompt_builder_page.dart';
import 'error_lab_page.dart';
import 'super_prompt_page.dart';

class ToolsPage extends StatelessWidget {
  const ToolsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ابزارها')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.construction_outlined),
              title: const Text('Prompt Builder'),
              subtitle: const Text('قالب‌ساز حرفه‌ای پرامپت + معیار پذیرش و ارزیابی'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PromptBuilderPage())),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.bug_report_outlined),
              title: const Text('Error Lab'),
              subtitle: const Text('متن خطا را بده؛ مسیر دیباگ مرحله‌ای بگیر'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ErrorLabPage())),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.auto_awesome_outlined),
              title: const Text('Super Prompt'),
              subtitle: const Text('یک پرامپت خیلی قدرتمند برای تولید اپ/پروژه بدون باگ'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SuperPromptPage())),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../../models/course.dart';
import '../../services/content_repository.dart';
import '../../services/progress_store.dart';
import '../../widgets/module_progress_bars.dart';
import '../lesson/lesson_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final repo = ContentRepository();
  final store = ProgressStore();

  List<Module> modules = const [];
  Set<String> completed = const {};
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final m = await repo.loadModulesFa();
      final c = await store.getCompleted();
      setState(() {
        modules = m;
        completed = c;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Map<String, double> _moduleProgress() {
    final map = <String, double>{};
    for (final m in modules) {
      if (m.lessons.isEmpty) {
        map[m.id] = 0;
        continue;
      }
      final done = m.lessons.where((l) => completed.contains(l.id)).length;
      map[m.id] = done / m.lessons.length;
    }
    return map;
  }

  Map<String, String> _moduleTitles() {
    return {for (final m in modules) m.id: m.title};
  }

  LessonRef? _nextLesson() {
    for (final m in modules) {
      for (final l in m.lessons) {
        if (!completed.contains(l.id)) return l;
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final next = _nextLesson();
    final totalLessons = modules.fold<int>(0, (p, m) => p + m.lessons.length);
    final completedCount = completed.length;
    final pct = totalLessons == 0 ? 0 : (completedCount / totalLessons);

    return Scaffold(
      appBar: AppBar(
        title: const Text('PromptCraft Academy'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? _ErrorView(error: error!, onRetry: _load)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('پیشرفت کلی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 10),
                              LinearProgressIndicator(value: pct),
                              const SizedBox(height: 8),
                              Text('$completedCount از $totalLessons درس کامل شده'),
                              const SizedBox(height: 8),
                              if (next != null)
                                FilledButton.icon(
                                  onPressed: () async {
                                    await Navigator.of(context).push(
                                      MaterialPageRoute(builder: (_) => LessonPage(lesson: next)),
                                    );
                                    await _load();
                                  },
                                  icon: const Icon(Icons.play_arrow),
                                  label: Text('ادامه: ${next.title}'),
                                )
                              else
                                const Text('آفرین! همه درس‌های فعلی را کامل کرده‌ای.'),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('نمای کلی ماژول‌ها', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 12),
                              ModuleProgressBars(
                                moduleProgress: _moduleProgress(),
                                moduleTitles: _moduleTitles(),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text('راهنمای سریع کیفیت پرامپت', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                              SizedBox(height: 8),
                              Text('۱) نقش/هدف را دقیق کن  ۲) ورودی/خروجی را قالب‌بندی کن  ۳) معیار پذیرش بده  ۴) Edge case و خطاها را پوشش بده'),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;
  const _ErrorView({required this.error, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48),
            const SizedBox(height: 12),
            const Text('خطا در بارگذاری', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(error, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('تلاش دوباره')),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    // منابع منتخب (برای مشاهده، اینترنت لازم است)
    final sections = <_Section>[
      _Section(
        title: 'پایه‌های مدل‌های زبانی',
        items: const [
          _Item(
            titleFa: 'ترنسفورمر (مبنای Attention)',
            titleEn: 'Attention Is All You Need',
            url: 'https://arxiv.org/abs/1706.03762',
            chip: 'پایه',
          ),
          _Item(
            titleFa: 'مدل‌های دستورپذیر و RLHF',
            titleEn: 'Training language models to follow instructions with human feedback',
            url: 'https://arxiv.org/abs/2203.02155',
            chip: 'دستورپذیری',
          ),
        ],
      ),
      _Section(
        title: 'پرامپت‌نویسی و الگوها',
        items: const [
          _Item(
            titleFa: 'مرور جامع پرامپت‌نویسی',
            titleEn: 'A Survey on Prompt Engineering',
            url: 'https://arxiv.org/abs/2406.06608',
            chip: 'Survey',
          ),
          _Item(
            titleFa: 'پرامپت‌نویسی خودکار',
            titleEn: 'Automated Prompt Engineering Survey',
            url: 'https://arxiv.org/abs/2401.11698',
            chip: 'Survey',
          ),
        ],
      ),
      _Section(
        title: 'RAG و ارزیابی',
        items: const [
          _Item(
            titleFa: 'مرور ارزیابی RAG',
            titleEn: 'RAG Evaluation Survey',
            url: 'https://arxiv.org/abs/2401.05845',
            chip: 'RAG',
          ),
        ],
      ),
      _Section(
        title: 'عامل‌ها و ابزارها',
        items: const [
          _Item(
            titleFa: 'الگوی Reason+Act (عامل‌ها)',
            titleEn: 'ReAct: Synergizing Reasoning and Acting in Language Models',
            url: 'https://arxiv.org/abs/2210.03629',
            chip: 'Agent',
          ),
          _Item(
            titleFa: 'یادگیری استفاده از ابزار',
            titleEn: 'Toolformer: Language Models Can Teach Themselves to Use Tools',
            url: 'https://arxiv.org/abs/2302.04761',
            chip: 'Tool',
          ),
        ],
      ),
      _Section(
        title: 'کورس‌ها و مسیر یادگیری',
        items: const [
          _Item(
            titleFa: 'دورهٔ «توسعه‌دهندهٔ مدرن نرم‌افزار» (نگاه AI‑محور)',
            titleEn: 'The Modern Software Developer',
            url: 'https://themodernsoftware.dev/',
            chip: 'Course',
          ),
        ],
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('کتابخانه')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: LinearGradient(colors: [cs.primaryContainer, cs.secondaryContainer]),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('منابع منتخب', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('برای مشاهده لینک‌ها، اینترنت لازم است. این فهرست کم‌حجم است اما «نقطه شروع درست» می‌دهد.'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          for (final section in sections) ...[
            _SectionHeader(title: section.title),
            const SizedBox(height: 8),
            for (final item in section.items) _ResourceCard(item: item, onTap: () => _open(item.url)),
            const SizedBox(height: 16),
          ],
        ],
      ),
    );
  }
}

class _Section {
  final String title;
  final List<_Item> items;

  const _Section({required this.title, required this.items});
}

class _Item {
  final String titleFa;
  final String titleEn;
  final String url;
  final String chip;

  const _Item({required this.titleFa, required this.titleEn, required this.url, required this.chip});
}

class _SectionHeader extends StatelessWidget {
  final String title;

  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.bookmark, size: 18),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class _ResourceCard extends StatelessWidget {
  final _Item item;
  final VoidCallback onTap;

  const _ResourceCard({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(item.titleFa, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(item.titleEn),
        ),
        leading: Chip(label: Text(item.chip)),
        trailing: const Icon(Icons.open_in_new),
        onTap: onTap,
      ),
    );
  }
}

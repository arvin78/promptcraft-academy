import 'package:flutter/material.dart';
import '../../models/quiz.dart';
import '../../services/content_repository.dart';
import '../../services/progress_store.dart';

class QuizPage extends StatefulWidget {
  final String lessonId;
  final String lessonTitle;

  const QuizPage({super.key, required this.lessonId, required this.lessonTitle});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final repo = ContentRepository();
  final store = ProgressStore();

  bool loading = true;
  String? error;
  List<QuizQuestion> questions = const [];
  int index = 0;
  int score = 0;
  int? selected;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
      index = 0;
      score = 0;
      selected = null;
    });
    try {
      final all = await repo.loadQuiz();
      final q = all.where((e) => e.lessonId == widget.lessonId).toList();
      setState(() {
        questions = q.isEmpty ? _fallback() : q;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  List<QuizQuestion> _fallback() {
    return [
      QuizQuestion(
        id: 'fallback1',
        lessonId: widget.lessonId,
        question: 'کدام گزینه برای افزایش کیفیت خروجی مدل، مهم‌تر است؟',
        options: ['حذف همه محدودیت‌ها', 'تعریف نقش/هدف و قالب خروجی', 'نوشتن متن خیلی طولانی بدون ساختار', 'استفاده از ایموجی زیاد'],
        correctIndex: 1,
        explanation: 'نقش/هدف + قالب خروجی + معیار پذیرش، کیفیت را پایدار می‌کند.',
      ),
    ];
  }

  Future<void> _finish() async {
    final best = await store.getQuizBest();
    final prev = best[widget.lessonId] ?? 0;
    if (score > prev) {
      best[widget.lessonId] = score;
      await store.setQuizBest(best);
    }
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('نتیجه کوییز'),
        content: Text('امتیاز: $score از ${questions.length}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشه')),
          FilledButton(onPressed: () { Navigator.pop(context); Navigator.pop(context); }, child: const Text('بازگشت')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('کوییز: ${widget.lessonTitle}')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : questions.isEmpty
                  ? const Center(child: Text('سوالی پیدا نشد.'))
                  : Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('سوال ${index + 1} از ${questions.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 12),
                          Text(questions[index].question, style: const TextStyle(fontSize: 18)),
                          const SizedBox(height: 12),
                          ...List.generate(questions[index].options.length, (i) {
                            final opt = questions[index].options[i];
                            return RadioListTile<int>(
                              value: i,
                              groupValue: selected,
                              onChanged: (v) => setState(() => selected = v),
                              title: Text(opt),
                            );
                          }),
                          const Spacer(),
                          if (selected != null)
                            Text(
                              selected == questions[index].correctIndex ? '✅ درست' : '❌ نادرست',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: selected == questions[index].correctIndex ? Colors.green : Colors.red,
                              ),
                            ),
                          const SizedBox(height: 8),
                          Text(questions[index].explanation),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: FilledButton(
                                  onPressed: selected == null
                                      ? null
                                      : () async {
                                          final correct = selected == questions[index].correctIndex;
                                          if (correct) score += 1;
                                          if (index + 1 >= questions.length) {
                                            await _finish();
                                          } else {
                                            setState(() {
                                              index += 1;
                                              selected = null;
                                            });
                                          }
                                        },
                                  child: Text(index + 1 >= questions.length ? 'پایان' : 'بعدی'),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
    );
  }
}

import 'package:flutter/material.dart';

import 'error_lab_page.dart';
import 'prompt_builder_page.dart';
import 'super_prompt_page.dart';

class ToolsPage extends StatelessWidget {
  const ToolsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ابزارهای حرفه‌ای'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: LinearGradient(
                colors: [
                  cs.primaryContainer,
                  cs.secondaryContainer,
                ],
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'کارگاه ابزارها',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                SizedBox(height: 8),
                Text(
                  'اینجا ابزارهایی داری که با آن‌ها می‌توانی پرامپت بسازی، خطاها را دیباگ کنی و سوپرپرامپت مسابقه‌ای تولید کنی.',
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _ToolCard(
            icon: Icons.auto_awesome,
            title: 'سازندهٔ پرامپت',
            subtitle: 'ساخت پرامپت ساختاریافته با قالب‌های حرفه‌ای (Role/Goal/Constraints/Output).',
            builder: PromptBuilderPage.new,
          ),
          const SizedBox(height: 12),
          _ToolCard(
            icon: Icons.bug_report,
            title: 'آزمایشگاه خطا',
            subtitle: 'کشف و اصلاح خطاهای رایج: ابهام، توهم، تناقض، خروجی بدون ساختار.',
            builder: ErrorLabPage.new,
          ),
          const SizedBox(height: 12),
          _ToolCard(
            icon: Icons.layers,
            title: 'سوپرپرامپت مسابقه‌ای',
            subtitle: 'تولید یک پرامپت چندبخشی، قابل تست و قابل استفاده در پروژه‌های واقعی.',
            builder: SuperPromptPage.new,
          ),
        ],
      ),
    );
  }
}

class _ToolCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget Function() builder;

  const _ToolCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.builder,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(subtitle),
        ),
        trailing: const Icon(Icons.chevron_left),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => builder()),
          );
        },
      ),
    );
  }
}

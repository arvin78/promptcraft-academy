import 'package:flutter/material.dart';

import '../../models/course.dart';
import '../../models/flashcards.dart';
import '../../services/content_repository.dart';
import '../../services/progress_store.dart';
import '../../services/srs_service.dart';
import '../lesson/lesson_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final repo = ContentRepository();
  final store = ProgressStore();

  bool loading = true;
  String? error;

  Course? course;
  int completed = 0;
  double pct = 0;

  LessonRef? nextLesson;
  double avgQuiz = 0;
  int dueFlashcards = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      await store.init();
      final c = await repo.loadCourse();

      final total = c.allLessons.length;
      final done = store.completedLessons.length;
      final progress = total == 0 ? 0.0 : (done / total);

      // اولین درسِ ناتمام
      LessonRef? next;
      for (final m in c.modules) {
        for (final l in m.lessons) {
          if (!store.isLessonCompleted(l.id)) {
            next = l;
            break;
          }
        }
        if (next != null) break;
      }

      // میانگین آزمون‌ها
      final scores = store.quizScores.values.toList(growable: false);
      final avg = scores.isEmpty ? 0.0 : scores.reduce((a, b) => a + b) / scores.length;

      // تعداد فلش‌کارت‌های سررسیدشده (SRS)
      final cards = await repo.loadFlashcards();
      final srsService = SrsService(store);
      final srs = await srsService.load();
      final now = DateTime.now();
      int due = 0;
      for (final card in cards) {
        final item = srs[card.id] ?? srsService.initialize(card.id);
        if (item.due.isBefore(now) || item.due.isAtSameMomentAs(now)) {
          due += 1;
        }
      }

      setState(() {
        course = c;
        completed = done;
        pct = progress.clamp(0.0, 1.0);
        nextLesson = next;
        avgQuiz = avg;
        dueFlashcards = due;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('داشبورد'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : Padding(
                  padding: const EdgeInsets.all(16),
                  child: ListView(
                    children: [
                      // هدر
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(24),
                          gradient: LinearGradient(
                            colors: [cs.primaryContainer, cs.secondaryContainer],
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'PromptCraft Academy',
                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'پیشرفت کلی: ${(pct * 100).toStringAsFixed(1)}٪',
                              style: TextStyle(color: cs.onPrimaryContainer),
                            ),
                            const SizedBox(height: 12),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(999),
                              child: LinearProgressIndicator(
                                value: pct,
                                minHeight: 10,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                _StatChip(label: 'درس‌های تکمیل‌شده', value: '$completed'),
                                _StatChip(label: 'میانگین آزمون', value: avgQuiz.toStringAsFixed(1)),
                                _StatChip(label: 'فلش‌کارت امروز', value: '$dueFlashcards'),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ادامه درس
                      if (nextLesson != null) ...[
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('ادامه بده', style: TextStyle(fontWeight: FontWeight.w900)),
                                const SizedBox(height: 8),
                                Text(nextLesson!.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                                const SizedBox(height: 12),
                                Row(
                                  children: [
                                    Expanded(
                                      child: FilledButton.icon(
                                        onPressed: () {
                                          Navigator.of(context).push(
                                            MaterialPageRoute(builder: (_) => LessonPage(lesson: nextLesson!)),
                                          );
                                        },
                                        icon: const Icon(Icons.play_arrow),
                                        label: const Text('شروع درس'),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // یک نگاه سریع
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text('راهنمای سریع کیفیت', style: TextStyle(fontWeight: FontWeight.w900)),
                              SizedBox(height: 8),
                              Text('• هدف را دقیق کن (یک‌جمله‌ای)'),
                              Text('• خروجی را قفل کن (فرمت + طول + ساختار)'),
                              Text('• معیار پذیرش بده (روبریک عددی)'),
                              Text('• تست‌کیس و edge-case بساز'),
                              Text('• حداقل تغییر بده و دوباره تست کن'),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;

  const _StatChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text('$label: $value'),
    );
  }
}

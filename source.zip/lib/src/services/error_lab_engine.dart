class ErrorHint {
  final String title;
  final List<String> patterns;
  final List<String> steps;

  const ErrorHint(this.title, this.patterns, this.steps);
}

class ErrorLabEngine {
  static final hints = <ErrorHint>[
    ErrorHint(
      'مشکل Assets (فایل پیدا نمی‌شود)',
      ['Unable to load asset', 'NoSuchMethodError: rootBundle', 'assets/'],
      [
        'در pubspec.yaml بخش assets را چک کن (فاصله‌ها مهم است).',
        'مطمئن شو فایل واقعاً وجود دارد و اسمش دقیقاً مطابق است (حروف بزرگ/کوچک).',
        'بعد از تغییر، دوباره workflow را اجرا کن.',
      ],
    ),
    ErrorHint(
      'مشکل Flutter/Dart Syntax (Expected to find ; / missing_identifier)',
      ['Expected to find', 'missing_identifier', 'unterminated_string_literal'],
      [
        'این خطا معمولاً از کوتیشن‌های شکسته یا متن چندخطی داخل '...'.',
        'در Dart برای متن چندخطی از """ استفاده کن، نه '...'.',
        'فایل خطادار را باز کن و همان خط/ستون را اصلاح کن.',
      ],
    ),
    ErrorHint(
      'مشکل Gradle/Java',
      ['Unsupported class file major version', 'Could not resolve', 'Gradle'],
      [
        'در workflow از Java 17 استفاده کن (setup-java).',
        'اگر باز هم خطا بود، یک بار فولدر android را دوباره بساز: flutter create --platforms android .',
        'بعد دوباره build بگیر.',
      ],
    ),
    ErrorHint(
      'مشکل پکیج‌ها (pub get failed)',
      ['pub get', 'version solving failed', 'Could not find package'],
      [
        'اسم پکیج را در pubspec.yaml چک کن.',
        'نسخه‌ها را ساده‌تر کن (مثلاً ^) یا یک نسخه پایدار بگذار.',
        'بعد دوباره اجرا کن.',
      ],
    ),
  ];

  static List<String> diagnose(String input) {
    final text = input.toLowerCase();
    final matched = <String>[];
    for (final h in hints) {
      if (h.patterns.any((p) => text.contains(p.toLowerCase()))) {
        matched.add('### ' + h.title);
        matched.addAll(h.steps.map((s) => '- ' + s));
        matched.add('');
      }
    }
    if (matched.isEmpty) {
      return [
        '### تشخیص خودکار پیدا نشد',
        '- لاگ کامل را کپی کن و مرحله‌ای که قرمز شده را مشخص کن.',
        '- معمولاً اولین خطا علت اصلی است؛ بقیه زنجیره‌ای هستند.',
      ];
    }
    return matched;
  }
}

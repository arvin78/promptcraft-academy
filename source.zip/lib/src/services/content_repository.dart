import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/course.dart';
import '../models/quiz.dart';
import '../models/flashcards.dart';

class ContentRepository {
  Future<List<Module>> loadModulesFa() async {
    final raw = await rootBundle.loadString('assets/data/curriculum_fa.json');
    final j = jsonDecode(raw) as Map<String, dynamic>;
    final list = (j['modules'] as List<dynamic>)
        .map((e) => Module.fromJson(e as Map<String, dynamic>))
        .toList();
    return list;
  }

  Future<String> loadLessonMarkdown(String lessonId) async {
    return rootBundle.loadString('assets/lessons/$lessonId.md');
  }

  Future<List<QuizQuestion>> loadQuiz() async {
    final raw = await rootBundle.loadString('assets/data/quizzes_fa.json');
    final j = jsonDecode(raw) as Map<String, dynamic>;
    return (j['questions'] as List<dynamic>)
        .map((e) => QuizQuestion.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<FlashCard>> loadFlashcards() async {
    final raw = await rootBundle.loadString('assets/data/flashcards_fa.json');
    final j = jsonDecode(raw) as Map<String, dynamic>;
    return (j['cards'] as List<dynamic>)
        .map((e) => FlashCard.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// Backward-compatible alias used by LessonPage.
  Future<String> loadLessonMd(String lessonId) => loadLessonMarkdown(lessonId);
}

class FlashCard {
  final String id;
  final String lessonId;
  final String front;
  final String back;

  const FlashCard({
    required this.id,
    required this.lessonId,
    required this.front,
    required this.back,
  });

  factory FlashCard.fromJson(Map<String, dynamic> j) => FlashCard(
        id: j['id'] as String,
        lessonId: j['lessonId'] as String,
        front: j['front'] as String,
        back: j['back'] as String,
      );
}

class SrsItem {
  final String cardId;
  final int intervalDays;
  final double ease;
  final DateTime due;

  const SrsItem({
    required this.cardId,
    required this.intervalDays,
    required this.ease,
    required this.due,
  });

  Map<String, dynamic> toJson() => {
        'cardId': cardId,
        'intervalDays': intervalDays,
        'ease': ease,
        'due': due.toIso8601String(),
      };

  factory SrsItem.fromJson(Map<String, dynamic> j) => SrsItem(
        cardId: j['cardId'] as String,
        intervalDays: (j['intervalDays'] as num).toInt(),
        ease: (j['ease'] as num).toDouble(),
        due: DateTime.parse(j['due'] as String),
      );
}

class QuizQuestion {
  final String id;
  final String lessonId;
  final String question;
  final List<String> options;
  final int correctIndex;
  final String explanation;

  const QuizQuestion({
    required this.id,
    required this.lessonId,
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.explanation,
  });

  factory QuizQuestion.fromJson(Map<String, dynamic> j) => QuizQuestion(
        id: j['id'] as String,
        lessonId: j['lessonId'] as String,
        question: j['question'] as String,
        options: (j['options'] as List<dynamic>).map((e) => e.toString()).toList(),
        correctIndex: (j['correctIndex'] as num).toInt(),
        explanation: j['explanation'] as String? ?? '',
      );
}

import 'package:flutter_test/flutter_test.dart';
import 'package:promptcraft_academy/src/app.dart';

void main() {
  testWidgets('App builds', (tester) async {
    await tester.pumpWidget(const PromptCraftApp());
    expect(find.text('PromptCraft Academy'), findsOneWidget);
  });
}

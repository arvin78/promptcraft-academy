class Module {
  final String id;
  final String title;
  final String summary;
  final List<LessonRef> lessons;

  const Module({
    required this.id,
    required this.title,
    required this.summary,
    required this.lessons,
  });

  factory Module.fromJson(Map<String, dynamic> j) => Module(
        id: j['id'] as String,
        title: j['title'] as String,
        summary: j['summary'] as String? ?? '',
        lessons: (j['lessons'] as List<dynamic>)
            .map((e) => LessonRef.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

class LessonRef {
  final String id;
  final String title;
  final String level; // beginner/intermediate/advanced
  final int minutes;
  final List<String> tags;
  final List<String> prereq;

  const LessonRef({
    required this.id,
    required this.title,
    required this.level,
    required this.minutes,
    required this.tags,
    required this.prereq,
  });

  factory LessonRef.fromJson(Map<String, dynamic> j) => LessonRef(
        id: j['id'] as String,
        title: j['title'] as String,
        level: j['level'] as String? ?? 'beginner',
        minutes: (j['minutes'] as num?)?.toInt() ?? 10,
        tags: (j['tags'] as List<dynamic>? ?? const [])
            .map((e) => e.toString())
            .toList(),
        prereq: (j['prereq'] as List<dynamic>? ?? const [])
            .map((e) => e.toString())
            .toList(),
      );
}

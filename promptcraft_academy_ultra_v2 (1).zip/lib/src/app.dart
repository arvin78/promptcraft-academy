import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'theme/app_theme.dart';
import 'features/dashboard/dashboard_page.dart';
import 'features/curriculum/curriculum_page.dart';
import 'features/library/library_page.dart';
import 'features/review/review_page.dart';
import 'features/tools/tools_page.dart';
import 'features/settings/settings_page.dart';

class PromptCraftApp extends StatefulWidget {
  const PromptCraftApp({super.key});

  @override
  State<PromptCraftApp> createState() => _PromptCraftAppState();
}

class _PromptCraftAppState extends State<PromptCraftApp> {
  int _index = 0;

  final _pages = const [
    DashboardPage(),
    CurriculumPage(),
    LibraryPage(),
    ReviewPage(),
    ToolsPage(),
    SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PromptCraft Academy',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.system,
      supportedLocales: const [Locale('fa', 'IR')],
      locale: const Locale('fa', 'IR'),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        // اجباری برای فارسی: RTL
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: Scaffold(
        body: SafeArea(child: _pages[_index]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard), label: 'داشبورد'),
            NavigationDestination(icon: Icon(Icons.school), label: 'دروس'),
            NavigationDestination(icon: Icon(Icons.book), label: 'کتابخانه'),
            NavigationDestination(icon: Icon(Icons.style), label: 'مرور'),
            NavigationDestination(icon: Icon(Icons.build), label: 'ابزارها'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'تنظیمات'),
          ],
        ),
      ),
    );
  }
}

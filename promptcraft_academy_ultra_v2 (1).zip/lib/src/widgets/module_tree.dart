import 'package:flutter/material.dart';
import '../models/course.dart';

class ModuleTree extends StatelessWidget {
  final List<Module> modules;
  final Set<String> completed;
  final void Function(LessonRef lesson) onOpenLesson;

  const ModuleTree({
    super.key,
    required this.modules,
    required this.completed,
    required this.onOpenLesson,
  });

  IconData _levelIcon(String level) {
    switch (level) {
      case 'advanced':
        return Icons.auto_awesome;
      case 'intermediate':
        return Icons.school;
      default:
        return Icons.play_circle_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        for (final m in modules)
          ExpansionTile(
            title: Text(m.title),
            subtitle: Text(m.summary, maxLines: 2, overflow: TextOverflow.ellipsis),
            children: [
              for (final l in m.lessons)
                ListTile(
                  leading: Icon(_levelIcon(l.level)),
                  title: Text(l.title),
                  subtitle: Text('${l.minutes} دقیقه • ${l.tags.take(3).join('، ')}'),
                  trailing: completed.contains(l.id)
                      ? const Icon(Icons.check_circle, color: Colors.green)
                      : const Icon(Icons.chevron_left),
                  onTap: () => onOpenLesson(l),
                ),
            ],
          ),
      ],
    );
  }
}

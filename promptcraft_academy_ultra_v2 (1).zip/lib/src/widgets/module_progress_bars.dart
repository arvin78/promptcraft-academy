import 'package:flutter/material.dart';

class ModuleProgressBars extends StatelessWidget {
  final Map<String, double> moduleProgress; // id -> 0..1
  final Map<String, String> moduleTitles;

  const ModuleProgressBars({
    super.key,
    required this.moduleProgress,
    required this.moduleTitles,
  });

  @override
  Widget build(BuildContext context) {
    final items = moduleProgress.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Column(
      children: [
        for (final e in items.take(6))
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: Text(
                    moduleTitles[e.key] ?? e.key,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 5,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(value: e.value),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(
                  width: 48,
                  child: Text('${(e.value * 100).round()}%'),
                )
              ],
            ),
          ),
      ],
    );
  }
}

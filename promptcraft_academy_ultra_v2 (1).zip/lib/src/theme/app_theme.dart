import 'package:flutter/material.dart';

/// طراحی بصری نسخه‌ی فارسیِ PromptCraft.
///
/// برای اینکه اپ روی گوشی‌های ضعیف هم روان بماند،
/// از انیمیشن‌های سنگین و تصویرهای بزرگ اجتناب شده و بیشتر از
/// Material 3 + فاصله‌گذاری + تایپوگرافی استفاده می‌کنیم.
class AppTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: Colors.indigo,
      brightness: Brightness.light,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: const Color(0xFFF6F7FB),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        foregroundColor: scheme.onSurface,
        titleTextStyle: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: scheme.onSurface,
        ),
      ),
      cardTheme: CardTheme(
        elevation: 1,
        shadowColor: Colors.black.withOpacity(0.06),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        margin: EdgeInsets.zero,
      ),
      chipTheme: ChipThemeData(
        shape: const StadiumBorder(),
        side: BorderSide(color: scheme.outlineVariant),
        labelStyle: const TextStyle(fontWeight: FontWeight.w700),
      ),
      dividerTheme: DividerThemeData(
        space: 24,
        thickness: 0.8,
        color: scheme.outlineVariant,
      ),
      listTileTheme: ListTileThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      textTheme: _textTheme(isDark: false),
      navigationBarTheme: NavigationBarThemeData(
        height: 68,
        indicatorColor: scheme.primaryContainer,
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: Colors.indigo,
      brightness: Brightness.dark,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: const Color(0xFF0E0F14),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        foregroundColor: scheme.onSurface,
        titleTextStyle: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: scheme.onSurface,
        ),
      ),
      cardTheme: CardTheme(
        elevation: 0.5,
        shadowColor: Colors.black.withOpacity(0.25),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        margin: EdgeInsets.zero,
      ),
      chipTheme: ChipThemeData(
        shape: const StadiumBorder(),
        side: BorderSide(color: scheme.outlineVariant),
        labelStyle: const TextStyle(fontWeight: FontWeight.w700),
      ),
      dividerTheme: DividerThemeData(
        space: 24,
        thickness: 0.8,
        color: scheme.outlineVariant,
      ),
      listTileTheme: ListTileThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      textTheme: _textTheme(isDark: true),
      navigationBarTheme: NavigationBarThemeData(
        height: 68,
        indicatorColor: scheme.primaryContainer,
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }

  static TextTheme _textTheme({required bool isDark}) {
    final base = Typography.material2021(platform: TargetPlatform.android);
    final text = (isDark ? base.white : base.black).apply(fontFamily: 'sans-serif');

    // ارتفاع خط برای فارسی و خوانایی بیشتر
    return text.copyWith(
      titleLarge: text.titleLarge?.copyWith(fontWeight: FontWeight.w900, height: 1.2),
      titleMedium: text.titleMedium?.copyWith(fontWeight: FontWeight.w900, height: 1.2),
      titleSmall: text.titleSmall?.copyWith(fontWeight: FontWeight.w800, height: 1.2),
      bodyLarge: text.bodyLarge?.copyWith(height: 1.65),
      bodyMedium: text.bodyMedium?.copyWith(height: 1.65),
      bodySmall: text.bodySmall?.copyWith(height: 1.65),
      labelLarge: text.labelLarge?.copyWith(fontWeight: FontWeight.w800),
      labelMedium: text.labelMedium?.copyWith(fontWeight: FontWeight.w800),
    );
  }
}

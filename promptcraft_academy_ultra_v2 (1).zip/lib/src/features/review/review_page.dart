import 'package:flutter/material.dart';
import '../../models/flashcards.dart';
import '../../services/content_repository.dart';
import '../../services/progress_store.dart';
import '../../services/srs_service.dart';

class ReviewPage extends StatefulWidget {
  const ReviewPage({super.key});

  @override
  State<ReviewPage> createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  final repo = ContentRepository();
  final store = ProgressStore();

  bool loading = true;
  String? error;

  List<FlashCard> cards = const [];
  Map<String, SrsItem> srs = {};
  int idx = 0;
  bool showBack = false;

  late final SrsService srsService = SrsService(store);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { loading = true; error = null; idx = 0; showBack = false; });
    try {
      final c = await repo.loadFlashcards();
      final s = await srsService.load();
      setState(() {
        cards = c;
        srs = s;
        loading = false;
      });
    } catch (e) {
      setState(() { error = e.toString(); loading = false; });
    }
  }

  List<FlashCard> _dueCards() {
    final now = DateTime.now();
    final due = <FlashCard>[];
    for (final c in cards) {
      final item = srs[c.id] ?? srsService.initialize(c.id);
      if (item.due.isBefore(now) || item.due.isAtSameMomentAs(now)) {
        due.add(c);
      }
    }
    return due;
  }

  Future<void> _rate(int rating) async {
    final due = _dueCards();
    if (due.isEmpty) return;
    final card = due[idx];
    final prev = srs[card.id] ?? srsService.initialize(card.id);
    final next = srsService.review(prev, rating);
    srs[card.id] = next;
    await srsService.save(srs);

    if (!mounted) return;
    setState(() {
      showBack = false;
      if (idx + 1 >= due.length) {
        idx = 0;
      } else {
        idx += 1;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final due = _dueCards();
    return Scaffold(
      appBar: AppBar(
        title: const Text('مرور (SRS)'),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : due.isEmpty
                  ? const Center(child: Text('برای امروز کارتِ سررسیدشده‌ای نداری. فردا دوباره بیا.'))
                  : Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Text('کارت ${idx + 1} از ${due.length}'),
                          const SizedBox(height: 12),
                          Expanded(
                            child: InkWell(
                              onTap: () => setState(() => showBack = !showBack),
                              child: Card(
                                child: Center(
                                  child: Padding(
                                    padding: const EdgeInsets.all(16),
                                    child: Text(
                                      showBack ? due[idx].back : due[idx].front,
                                      style: const TextStyle(fontSize: 18),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          const Text('امتیاز بده (۰ بد — ۵ عالی):'),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            children: [
                              for (final r in [0,1,2,3,4,5])
                                OutlinedButton(
                                  onPressed: () => _rate(r),
                                  child: Text('$r'),
                                )
                            ],
                          ),
                        ],
                      ),
                    ),
    );
  }
}

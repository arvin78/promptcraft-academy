import 'package:flutter/material.dart';

import '../../models/course.dart';
import '../../services/content_repository.dart';
import '../../services/progress_store.dart';
import '../lesson/lesson_page.dart';

class CurriculumPage extends StatefulWidget {
  const CurriculumPage({super.key});

  @override
  State<CurriculumPage> createState() => _CurriculumPageState();
}

class _CurriculumPageState extends State<CurriculumPage> {
  final repo = ContentRepository();
  final store = ProgressStore();

  bool loading = true;
  String? error;
  List<Module> modules = [];
  String query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      await store.init();
      final m = await repo.loadModulesFa();
      setState(() {
        modules = m;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  List<Module> get filtered {
    if (query.trim().isEmpty) return modules;
    final q = query.trim();

    bool containsIgnoreCase(String haystack, String needle) =>
        haystack.toLowerCase().contains(needle.toLowerCase());

    return modules.map((m) {
      final keepModule = containsIgnoreCase(m.title, q) || containsIgnoreCase(m.summary, q);
      final lessons = m.lessons.where((l) {
        return keepModule ||
            containsIgnoreCase(l.title, q) ||
            l.tags.any((t) => containsIgnoreCase(t, q));
      }).toList();

      return Module(id: m.id, title: m.title, summary: m.summary, lessons: lessons);
    }).where((m) => m.lessons.isNotEmpty).toList();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('دروس'),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        gradient: LinearGradient(colors: [cs.primaryContainer, cs.secondaryContainer]),
                      ),
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('مسیر آموزشی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                          SizedBox(height: 8),
                          Text('هر ماژول چند درس کوتاه دارد. هدف این است که هر درس «تمرین‌محور» و قابل ارزیابی باشد.'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'جستجو در درس‌ها و تگ‌ها…',
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (v) => setState(() => query = v),
                    ),
                    const SizedBox(height: 16),
                    for (final m in filtered) _ModuleCard(module: m, store: store),
                  ],
                ),
    );
  }
}

class _ModuleCard extends StatelessWidget {
  final Module module;
  final ProgressStore store;

  const _ModuleCard({required this.module, required this.store});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final total = module.lessons.length;
    final done = module.lessons.where((l) => store.isLessonCompleted(l.id)).length;
    final pct = total == 0 ? 0.0 : done / total;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        childrenPadding: const EdgeInsets.only(bottom: 8),
        title: Text(module.title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 6),
            Text(module.summary),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(999),
                    child: LinearProgressIndicator(value: pct, minHeight: 8),
                  ),
                ),
                const SizedBox(width: 8),
                Text('$done/$total', style: TextStyle(color: cs.onSurfaceVariant)),
              ],
            ),
          ],
        ),
        children: [
          for (final lesson in module.lessons)
            ListTile(
              title: Text(lesson.title),
              subtitle: lesson.tags.isEmpty
                  ? null
                  : Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        for (final t in lesson.tags.take(4)) Chip(label: Text(t)),
                      ],
                    ),
              leading: Icon(
                store.isLessonCompleted(lesson.id) ? Icons.check_circle : Icons.radio_button_unchecked,
                color: store.isLessonCompleted(lesson.id) ? cs.primary : cs.outline,
              ),
              trailing: Text('${lesson.minutes}دقیقه'),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => LessonPage(lesson: lesson)),
                );
              },
            ),
        ],
      ),
    );
  }
}

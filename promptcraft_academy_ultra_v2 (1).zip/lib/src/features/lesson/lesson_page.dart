import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

import '../../models/course.dart';
import '../../services/content_repository.dart';
import '../../services/progress_store.dart';

class LessonPage extends StatefulWidget {
  final LessonRef lesson;
  const LessonPage({super.key, required this.lesson});

  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  final repo = ContentRepository();
  final store = ProgressStore();

  bool loading = true;
  String? error;
  String md = '';
  bool completed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  String _levelFa(String level) {
    switch (level) {
      case 'beginner':
        return 'مبتدی';
      case 'intermediate':
        return 'متوسط';
      case 'advanced':
        return 'پیشرفته';
      default:
        return level;
    }
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      await store.init();
      final content = await repo.loadLessonMd(widget.lesson.id);
      setState(() {
        md = content;
        completed = store.isLessonCompleted(widget.lesson.id);
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _toggleCompleted() async {
    final newValue = !completed;
    setState(() => completed = newValue);

    if (newValue) {
      await store.completeLesson(widget.lesson.id);
    } else {
      await store.uncompleteLesson(widget.lesson.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final style = MarkdownStyleSheet.fromTheme(Theme.of(context)).copyWith(
      h1: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
      h2: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
      h3: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
      p: Theme.of(context).textTheme.bodyMedium,
      code: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontFamily: 'monospace',
            fontSize: 13,
            height: 1.6,
          ),
      codeblockPadding: const EdgeInsets.all(12),
      codeblockDecoration: BoxDecoration(
        color: cs.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      blockquoteDecoration: BoxDecoration(
        color: cs.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.lesson.title),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    // هدر درس
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                Chip(label: Text('سطح: ${_levelFa(widget.lesson.level)}')),
                                Chip(label: Text('زمان: ${widget.lesson.minutes} دقیقه')),
                                if (widget.lesson.tags.isNotEmpty)
                                  ...widget.lesson.tags.take(3).map((t) => Chip(label: Text(t))),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              completed ? '✅ این درس تکمیل شده' : '⏳ این درس هنوز تکمیل نشده',
                              style: TextStyle(
                                fontWeight: FontWeight.w900,
                                color: completed ? cs.primary : cs.onSurface,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'پیشنهاد: بعد از خواندن، تمرین‌ها را انجام بده و سپس آزمون بزن تا این درس در حافظه‌ات تثبیت شود.',
                              style: TextStyle(color: cs.onSurfaceVariant),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: MarkdownBody(
                          data: md,
                          styleSheet: style,
                          selectable: true,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: _toggleCompleted,
                            icon: Icon(completed ? Icons.undo : Icons.check),
                            label: Text(completed ? 'برداشتن تکمیل' : 'علامت‌گذاری به‌عنوان تکمیل'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
    );
  }
}

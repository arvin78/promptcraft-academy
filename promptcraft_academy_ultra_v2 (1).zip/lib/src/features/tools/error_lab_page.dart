import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/error_lab_engine.dart';
import '../../services/progress_store.dart';

class ErrorLabPage extends StatefulWidget {
  const ErrorLabPage({super.key});

  @override
  State<ErrorLabPage> createState() => _ErrorLabPageState();
}

class _ErrorLabPageState extends State<ErrorLabPage> {
  final input = TextEditingController();
  final store = ProgressStore();
  List<String> output = const [];

  Future<void> _analyze() async {
    final text = input.text.trim();
    if (text.isEmpty) return;
    await store.addErrorLog(text);
    setState(() => output = ErrorLabEngine.diagnose(text));
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData('text/plain');
    input.text = data?.text ?? '';
    setState(() {});
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('آزمایشگاه خطا'),
        actions: [
          IconButton(onPressed: _paste, icon: const Icon(Icons.content_paste)),
          IconButton(onPressed: _analyze, icon: const Icon(Icons.auto_fix_high)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('متن خطا را بچسبان و دکمه ✨ را بزن.'),
          const SizedBox(height: 12),
          TextField(
            controller: input,
            maxLines: 10,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'مثلاً لاگ GitHub Actions یا خطای Flutter...',
            ),
          ),
          const SizedBox(height: 12),
          if (output.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('پیشنهاد دیباگ', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    for (final line in output) Text(line),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

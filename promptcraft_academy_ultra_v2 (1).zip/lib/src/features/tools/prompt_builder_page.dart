import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PromptBuilderPage extends StatefulWidget {
  const PromptBuilderPage({super.key});

  @override
  State<PromptBuilderPage> createState() => _PromptBuilderPageState();
}

class _PromptBuilderPageState extends State<PromptBuilderPage> {
  final role = TextEditingController(text: 'معمار نرم‌افزار و مهندس ارشد Flutter');
  final goal = TextEditingController(text: 'ساخت اپ اندروید آفلاین با کیفیت تولیدی و CI');
  final context = TextEditingController(text: 'کاربر مبتدی است؛ خروجی باید قابل اجرا و بدون سوال اضافه باشد.');
  final inputs = TextEditingController(text: 'قابلیت‌ها، صفحات، مدل داده، استایل UI');
  final constraints = TextEditingController(text: 'آفلاین، Material 3، مدیریت خطا، تست، GitHub Actions');
  final outputFormat = TextEditingController(text: 'ریپو کامل + فایل‌ها با مسیر + README + workflow');
  final acceptance = TextEditingController(text: 'flutter analyze بدون error؛ build apk موفق؛ UX شامل loading/error/empty');

  String built = '';

  void _build() {
    built = '''
نقش شما: ${role.text}

هدف: ${goal.text}

زمینه/کانتکست:
${context.text}

ورودی‌ها:
${inputs.text}

محدودیت‌ها:
${constraints.text}

قالب خروجی:
${outputFormat.text}

معیار پذیرش (Quality Gate):
${acceptance.text}

قوانین مهم:
- اگر چیزی مبهم است فرض معقول بساز و در جدول Assumptions بنویس.
- برای هر صفحه حالت‌های درحال بارگذاری/خطا/خالی ارائه بده.
- خطاهای احتمالی و پیام‌های کاربرپسند را طراحی کن.
- قبل از پایان، یک بخش Final verification با چک‌لیست تست و بیلد بده.
''';
    setState(() {});
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: built));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کپی شد')));
  }

  @override
  void dispose() {
    role.dispose(); goal.dispose(); context.dispose(); inputs.dispose();
    constraints.dispose(); outputFormat.dispose(); acceptance.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('سازندهٔ پرامپت'),
        actions: [
          IconButton(onPressed: _build, icon: const Icon(Icons.play_arrow)),
          IconButton(onPressed: built.isEmpty ? null : _copy, icon: const Icon(Icons.copy)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('فیلدها را پر کن، بعد دکمه ▶ را بزن.'),
          const SizedBox(height: 12),
          _field('نقش', role),
          _field('هدف', goal),
          _field('کانتکست', context, lines: 3),
          _field('ورودی‌ها', inputs, lines: 3),
          _field('محدودیت‌ها', constraints, lines: 3),
          _field('قالب خروجی', outputFormat, lines: 2),
          _field('معیار پذیرش', acceptance, lines: 3),
          const SizedBox(height: 16),
          if (built.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: SelectableText(built),
              ),
            )
        ],
      ),
    );
  }

  Widget _field(String label, TextEditingController c, {int lines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        maxLines: lines,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}

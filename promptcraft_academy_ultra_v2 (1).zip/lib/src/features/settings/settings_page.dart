import 'package:flutter/material.dart';
import '../../services/progress_store.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final store = ProgressStore();
  bool loading = true;
  List<String> logs = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    final l = await store.getErrorLogs();
    setState(() {
      logs = l;
      loading = false;
    });
  }

  Future<void> _reset() async {
    await store.resetAll();
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('همه چیز ریست شد')));
  }

  Future<void> _clearLogs() async {
    await store.clearErrorLogs();
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.restart_alt),
                    title: const Text('ریست کامل پیشرفت و داده‌ها'),
                    subtitle: const Text('پیشرفت، نتایج کوییز، لاگ خطا و مرور پاک می‌شود'),
                    onTap: _reset,
                  ),
                ),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.bug_report),
                    title: const Text('پاک‌کردن لاگ خطاها'),
                    subtitle: Text('تعداد: ${logs.length}'),
                    onTap: _clearLogs,
                  ),
                ),
                const SizedBox(height: 12),
                const Text('آخرین لاگ‌ها', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                if (logs.isEmpty) const Text('لاگی ثبت نشده.'),
                for (final l in logs.take(10))
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(l, maxLines: 6, overflow: TextOverflow.ellipsis),
                    ),
                  ),
              ],
            ),
    );
  }
}

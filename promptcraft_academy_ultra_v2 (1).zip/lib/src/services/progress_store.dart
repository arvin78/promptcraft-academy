import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ProgressStore {
  static const _kCompleted = 'completed_lessons';
  static const _kQuizBest = 'quiz_best_scores';
  static const _kErrorLog = 'error_logs';
  static const _kSrs = 'srs_items';

  Future<Set<String>> getCompleted() async {
    final sp = await SharedPreferences.getInstance();
    final list = sp.getStringList(_kCompleted) ?? const [];
    return list.toSet();
  }

  Future<void> setCompleted(Set<String> ids) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setStringList(_kCompleted, ids.toList()..sort());
  }

  Future<Map<String, int>> getQuizBest() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(_kQuizBest);
    if (raw == null) return {};
    final j = jsonDecode(raw) as Map<String, dynamic>;
    return j.map((k, v) => MapEntry(k, (v as num).toInt()));
  }

  Future<void> setQuizBest(Map<String, int> best) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kQuizBest, jsonEncode(best));
  }

  Future<List<String>> getErrorLogs() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getStringList(_kErrorLog) ?? const [];
  }

  Future<void> addErrorLog(String log) async {
    final sp = await SharedPreferences.getInstance();
    final list = (sp.getStringList(_kErrorLog) ?? <String>[])..insert(0, log);
    // keep last 50
    if (list.length > 50) list.removeRange(50, list.length);
    await sp.setStringList(_kErrorLog, list);
  }

  Future<void> clearErrorLogs() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove(_kErrorLog);
  }

  Future<String?> getSrsRaw() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getString(_kSrs);
  }

  Future<void> setSrsRaw(String raw) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kSrs, raw);
  }

  Future<void> resetAll() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove(_kCompleted);
    await sp.remove(_kQuizBest);
    await sp.remove(_kErrorLog);
    await sp.remove(_kSrs);
  }
}

import 'dart:convert';
import '../models/flashcards.dart';
import 'progress_store.dart';

class SrsService {
  final ProgressStore store;
  SrsService(this.store);

  // Simple SM-2 inspired scheduling. rating: 0..5
  Future<Map<String, SrsItem>> load() async {
    final raw = await store.getSrsRaw();
    if (raw == null) return {};
    final j = jsonDecode(raw) as Map<String, dynamic>;
    return j.map((k, v) => MapEntry(k, SrsItem.fromJson(v as Map<String, dynamic>)));
  }

  Future<void> save(Map<String, SrsItem> items) async {
    final j = items.map((k, v) => MapEntry(k, v.toJson()));
    await store.setSrsRaw(jsonEncode(j));
  }

  SrsItem initialize(String cardId) {
    return SrsItem(
      cardId: cardId,
      intervalDays: 0,
      ease: 2.5,
      due: DateTime.now(),
    );
  }

  SrsItem review(SrsItem prev, int rating) {
    final r = rating.clamp(0, 5);
    double ease = prev.ease + (0.1 - (5 - r) * (0.08 + (5 - r) * 0.02));
    if (ease < 1.3) ease = 1.3;

    int interval;
    if (r < 3) {
      interval = 1; // reset
    } else {
      if (prev.intervalDays <= 1) {
        interval = 1;
      } else if (prev.intervalDays == 1) {
        interval = 6;
      } else {
        interval = (prev.intervalDays * ease).round();
      }
    }

    final due = DateTime.now().add(Duration(days: interval));
    return SrsItem(cardId: prev.cardId, intervalDays: interval, ease: ease, due: due);
  }
}

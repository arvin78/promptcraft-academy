import 'package:flutter_test/flutter_test.dart';
import 'package:promptcraft_academy/src/models/flashcards.dart';
import 'package:promptcraft_academy/src/services/srs_service.dart';
import 'package:promptcraft_academy/src/services/progress_store.dart';

class _FakeStore extends ProgressStore {
  String? raw;
  @override
  Future<String?> getSrsRaw() async => raw;

  @override
  Future<void> setSrsRaw(String raw) async {
    this.raw = raw;
  }
}

void main() {
  test('SRS review increases due date', () async {
    final store = _FakeStore();
    final s = SrsService(store);
    final item = s.initialize('c1');
    final next = s.review(item, 5);
    expect(next.due.isAfter(DateTime.now().subtract(const Duration(seconds: 1))), true);
    expect(next.ease >= 1.3, true);
  });
}

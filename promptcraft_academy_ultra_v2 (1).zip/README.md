# PromptCraft Academy (Flutter / Android - فارسی)

این پروژه به‌صورت «ZIP → GitHub Actions → APK» طراحی شده تا حتی با گوشی و بدون دانش برنامه‌نویسی بتوانی خروجی APK بگیری.

## ویژگی‌های اصلی
- کاملاً فارسی + راست‌به‌چپ
- آفلاین (بدون نیاز به اینترنت برای درس‌ها)
- مسیر آموزشی بزرگ (۱۶ ماژول / ۱۲۸ درس)
- آزمون‌ها و فلش‌کارت‌ها برای تثبیت یادگیری
- ابزارهای داخلی: سازنده پرامپت، آزمایشگاه خطا، سوپرپرامپت مسابقه‌ای

## خروجی گرفتن APK (arm64‑v8a)
1) فایل ZIP پروژه را در ریشه Repo آپلود کن.
2) فایل Workflow را در مسیر `.github/workflows/build.yml` قرار بده.
3) به تب **Actions** برو و Workflow را اجرا کن.
4) از **Artifacts** فایل `app-arm64-v8a-release.apk` را دانلود و نصب کن.

> اگر قبلاً نسخه‌ی Debug نصب کرده باشی، برای نصب نسخه‌ی Release معمولاً باید اپ قبلی را حذف (Uninstall) کنی.

## توسعه محتوا (بدون کدنویسی)
- مسیر آموزشی: `assets/data/curriculum_fa.json`
- آزمون‌ها: `assets/data/quizzes_fa.json`
- فلش‌کارت‌ها: `assets/data/flashcards_fa.json`
- متن هر درس: `assets/lessons/<lessonId>.md`

## نکته
پیشرفت کاربر با `SharedPreferences` روی گوشی ذخیره می‌شود.
